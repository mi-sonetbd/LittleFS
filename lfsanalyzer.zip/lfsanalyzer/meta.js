document.getElementById('load-button').addEventListener('click', async () => {
  const fileInput = document.getElementById('img-file-input');
  const blockSizeInput = document.getElementById('img-block-size-input');
  const blockCountInput = document.getElementById('img-block-count-input');
  const readSizeInput = document.getElementById('img-read-size-input');
  const cacheSizeInput = document.getElementById('img-cache-size-input');
  const lookaheadSizeInput = document.getElementById('img-lookahead-size-input');
  const maxCachedBlocksInput = document.getElementById('max-cached-blocks-input');

  if (!fileInput.files.length) {
    alert('Please select a file.');
    return;
  }

  const file = fileInput.files[0];
  const blockSize = parseInt(blockSizeInput.value, 10);
  const blockCount = parseInt(blockCountInput.value, 10);
  const readSize = parseInt(readSizeInput.value, 10);
  const cacheSize = parseInt(cacheSizeInput.value, 10);
  const lookaheadSize = parseInt(lookaheadSizeInput.value, 10);
  const maxCachedBlocks = parseInt(maxCachedBlocksInput.value, 10);

  const reader = await createLfsImageReader({
    read: createFileReader(file, blockSize, blockCount, maxCachedBlocks)
  });

  await loadLittleFSMetadata(reader, { blockSize, blockCount, readSize, cacheSize, lookaheadSize });
});
