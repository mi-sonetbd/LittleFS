import os
import time
from datetime import datetime

def append_timestamp(filename):
    with open(filename, 'a') as file:
        timestamp = datetime.now().strftime("[%Y-%m-%d %H:%M:%S]\n")
        file.write(timestamp)

def monitor_log_file(filename):
    last_size = 0
    while True:
        try:
            # Confirm file exists before checking its size
            if not os.path.exists(filename):
                print(f"File '{filename}' does not exist. Waiting for it to be created...")
                time.sleep(1)
                continue
            
            # Check file size for new content
            current_size = os.path.getsize(filename)
            if current_size > last_size:
                # If file has grown, append timestamp
                append_timestamp(filename)
                last_size = current_size
            time.sleep(1)  # Check every second
        except KeyboardInterrupt:
            print("Stopping monitoring.")
            break
        except Exception as e:
            print(f"Error: {e}")
            break

if __name__ == "__main__":
    log_filename = "uart_log.txt"
    monitor_log_file(log_filename)
