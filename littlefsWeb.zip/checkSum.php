<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JAHAJI - OTA Update Diagnostics</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        main {
            flex: 1;
        }
        .not-equal { color: red; font-weight: bold; }
        .zero-difference { color: blueviolet; font-weight: bold; }
        .custom-outline {
            text-shadow: -1px -1px 0 #fff, 1px -1px 0 #fff, -1px 1px 0 #fff, 1px 1px 0 #fff;
        }
    </style>
</head>
<body class="bg-gray-100">

    <!-- Header -->
    <header class="bg-blue-900 text-white shadow-lg py-4 sticky top-0 z-50">
        <div class="container mx-auto flex justify-between items-center px-4">
            <h1 class="text-3xl font-bold">
                <span class="font-bold">JAHAJI</span>
                <span class="font-normal text-gray-600 custom-outline"> - by TETON</span>
            </h1>
            <nav>
                <a href="index.html" class="text-white hover:text-gray-200 px-3">Home</a>
                <a href="about.html" class="text-white hover:text-gray-200 px-3">About</a>
                <a href="contact.html" class="text-white hover:text-gray-200 px-3">Contact</a>
                <a href="d2.php" class="text-white hover:text-gray-200 px-3">ReadIssue</a>
                                <a href="checkSum.php" class="text-white hover:text-gray-200 px-3">CheckSum Issue</a>
            </nav>
        </div>
    </header>

    <!-- Main Content -->
    <main class="container mx-auto px-4 py-8">
        <h3 class="text-3xl font-bold text-gray-700 mb-6">OTA Update Diagnostics</h3> 

        <textarea id="inputText" rows="4" class="w-full p-4 border border-gray-300 rounded-lg mb-4" placeholder="Paste your GSM RX Log below to find issue"></textarea>
        <button onclick="checkMultiples()" class="bg-blue-600 text-white py-2 px-4 rounded-lg shadow-md hover:bg-blue-700">Find Devils</button>

        <h3 class="text-xl font-semibold text-gray-700 mt-6">Discrepancies:</h3>
        <table border="1" id="resultTable" class="w-full mt-4 border-collapse">
            <tr class="bg-gray-200">
                <th class="p-2 border">Timestamp</th>
                <th class="p-2 border">Command</th>
                <th class="p-2 border">Number</th>
                <th class="p-2 border">Status</th>
                <th class="p-2 border">Difference</th>
            </tr>
        </table>
    </main>

    <!-- Footer -->
    <footer class="bg-blue-900 text-white py-4 mt-auto">
        <div class="container mx-auto text-center">
            <p class="text-sm">&copy; Morshedul Islam Sonet. All rights reserved.</p>
            <nav class="flex justify-center space-x-4">
                <a href="privacy.html" class="text-white hover:text-gray-300">Privacy Policy</a>
                <a href="terms.html" class="text-white hover:text-gray-300">Terms of Service</a>
            </nav>
        </div>
    </footer>

    <!-- JavaScript Function -->
    <script>
        function checkMultiples() {
            const text = document.getElementById('inputText').value;
            const resultTable = document.getElementById('resultTable');
            const increment = 1024;
            let withinSection = false;
            let previousValue = 0;

            // Clear previous results
            resultTable.innerHTML = `
                <tr class="bg-gray-200">
                    <th class="p-2 border">Timestamp</th>
                    <th class="p-2 border">Command</th>
                    <th class="p-2 border">Number</th>
                    <th class="p-2 border">Status</th>
                    <th class="p-2 border">Difference</th>
                </tr>`;

            // Split the text by lines
            const lines = text.split('\n');

            // Process lines between AT+HTTPACTION = 0 and AT+HTTPTERM markers
            lines.forEach(line => {
                if (line.includes('AT+HTTPACTION = 0')) {
                    withinSection = true;
                    previousValue = 0; // Reset expected sequence for a new section
                } else if (line.includes('AT+HTTPTERM')) {
                    withinSection = false; // End section
                } else if (withinSection) {
                    const regex = /(\d{2}-\w{3}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3}) \[RX\] - (AT\+HTTPREAD=)(\d+),/;
                    const match = line.match(regex);

                    if (match) {
                        const timestamp = match[1];
                        const command = match[2];
                        const number = parseInt(match[3], 10);

                        // Skip lines where AT+HTTPREAD=0
                        if (number === 0) {
                            return;
                        }

                        const isMultiple = (number - previousValue) === increment;
                        const difference = isMultiple ? '' : Math.abs(number - previousValue);

                        // Update previous value to current number for the next line
                        previousValue = number;

                        // Determine the status and style based on the difference
                        let statusText = "Devil";
                        let statusClass = "not-equal";

                        if (difference === 0) {
                            statusText = "X";
                            statusClass = "zero-difference";
                        }

                        // Only display the row if it is "Not Equal"
                        if (!isMultiple) {
                            const row = document.createElement('tr');
                            row.innerHTML = `
                                <td class="p-2 border">${timestamp}</td>
                                <td class="p-2 border">${command}</td>
                                <td class="p-2 border">${number}</td>
                                <td class="p-2 border ${statusClass}">${statusText}</td>
                                <td class="p-2 border">${difference}</td>
                            `;
                            resultTable.appendChild(row);
                        }
                    }
                }
            });
            
            document.getElementById('inputText').value = '';
        }
    </script>
</body>
</html>
