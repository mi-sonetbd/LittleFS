<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DMA Buffer Decoder</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        main {
            flex: 1;
        }
        .custom-outline {
            text-shadow: -1px -1px 0 #fff, 1px -1px 0 #fff, -1px 1px 0 #fff, 1px 1px 0 #fff;
        }
        .page-content {
            width: 48%;
            padding: 10px;
            border: 1px solid #ccc;
            background-color: #f9f9f9;
            margin: 10px;
            white-space: pre-wrap;
        }
        .highlight {
            background-color: yellow;
        }
        .memory-address {
            color: gray;
            font-weight: bold;
            margin-right: 10px;
        }
    </style>
</head>
<body class="bg-gray-100">

    <!-- Header -->
    <header class="bg-blue-900 text-white shadow-lg py-4 sticky top-0 z-50">
        <div class="container mx-auto flex justify-between items-center px-4">
            <h1 class="text-3xl font-bold">
                <span class="font-bold">JAHAJI</span>
                <span class="font-normal text-gray-600 custom-outline"> - by TETON</span>
            </h1>
            <nav>
                <a href="index.html" class="text-white hover:text-gray-200 px-3">Home</a>
                <a href="about.html" class="text-white hover:text-gray-200 px-3">About</a>
                <a href="contact.html" class="text-white hover:text-gray-200 px-3">Contact</a>
                <a href="d2.php" class="text-white hover:text-gray-200 px-3">ReadIssue</a>
                                <a href="checkSum.php" class="text-white hover:text-gray-200 px-3">CheckSum Issue</a>
            </nav>
        </div>
    </header>

    <!-- Main Content -->
    <main class="container mx-auto px-4 py-8">
        <h3 class="text-3xl font-bold text-gray-700 mb-6">DMA Buffer Decoder</h3> 

        <label for="hexInput" class="block text-lg font-medium text-gray-700 mb-2">Paste your hex buffer contents here:</label>
        <textarea id="hexInput" rows="10" class="w-full p-4 border border-gray-300 rounded-lg mb-4" placeholder="Paste your hex buffer data here"></textarea>
        <button onclick="decodeUniquePages()" class="bg-blue-600 text-white py-2 px-4 rounded-lg shadow-md hover:bg-blue-700">Decode and Compare</button>

        <div class="flex justify-between mt-6">
            <div id="page1" class="page-content"></div>
            <div id="page2" class="page-content"></div>
        </div>

        <div class="flex justify-center mt-4">
            <button onclick="prevPage()" class="bg-gray-500 text-white py-2 px-4 rounded-lg mx-2">Previous</button>
            <button onclick="nextPage()" class="bg-blue-600 text-white py-2 px-4 rounded-lg mx-2">Next</button>
        </div>
    </main>

    <!-- JavaScript Function -->
    <script>
        let currentPage = 0;
        let uniquePages = [];

        function decodeUniquePages() {
            const rawInput = document.getElementById("hexInput").value;

            // Split input by "Buffer contents:" sections (assuming each page starts with this)
            const pages = rawInput.split(/Buffer contents:/).map(page => page.trim()).filter(page => page);

            let lastPage = null;
            uniquePages = [];

            // Filter unique pages
            pages.forEach(page => {
                if (page !== lastPage) {
                    uniquePages.push(page);
                    lastPage = page;
                }
            });

            // Display the first page pair
            displayPagePair();
        }

        function displayPagePair() {
            if (uniquePages.length < 2) {
                document.getElementById("page1").innerText = "Not enough unique pages to compare.";
                document.getElementById("page2").innerText = "";
                return;
            }

            // Ensure currentPage index stays within bounds
            if (currentPage < 0) currentPage = 0;
            if (currentPage >= uniquePages.length - 1) currentPage = uniquePages.length - 2;

            const page1Content = decodeHexWithAddress(uniquePages[currentPage], 0x20002798);
            const page2Content = decodeHexWithAddress(uniquePages[currentPage + 1], 0x20002798);

            // Highlight differences between the two pages
            const [highlightedPage1, highlightedPage2] = highlightDifferences(page1Content, page2Content);

            document.getElementById("page1").innerHTML = `<h4>Page ${currentPage + 1}</h4><pre>${highlightedPage1}</pre>`;
            document.getElementById("page2").innerHTML = `<h4>Page ${currentPage + 2}</h4><pre>${highlightedPage2}</pre>`;
        }

        function decodeHexWithAddress(page, startAddress) {
            const hexArray = page.match(/0x[0-9A-Fa-f]{2}/g);
            let decodedString = "";
            let address = startAddress;

            if (hexArray) {
                hexArray.forEach((hex, index) => {
                    // Add memory address at the start of each line, every 16 bytes
                    if (index % 16 === 0) {
                        decodedString += `<span class="memory-address">0x${address.toString(16).toUpperCase().padStart(8, '0')}</span> `;
                    }

                    // Convert hex to ASCII
                    const char = String.fromCharCode(parseInt(hex, 16));
                    decodedString += char.replace(/[\x00-\x1F\x7F-\x9F]/g, '.'); // Replace non-printable ASCII chars

                    // Add line break after 16 characters
                    if ((index + 1) % 16 === 0) decodedString += '\n';

                    // Increment address
                    address++;
                });
            }
            return decodedString;
        }

        function highlightDifferences(content1, content2) {
            let highlighted1 = '';
            let highlighted2 = '';

            // Compare characters of content1 and content2
            for (let i = 0; i < Math.max(content1.length, content2.length); i++) {
                const char1 = content1[i] || '';
                const char2 = content2[i] || '';

                if (char1 !== char2) {
                    // Highlight differences
                    highlighted1 += `<span class="highlight">${char1}</span>`;
                    highlighted2 += `<span class="highlight">${char2}</span>`;
                } else {
                    highlighted1 += char1;
                    highlighted2 += char2;
                }
            }

            return [highlighted1, highlighted2];
        }

        function prevPage() {
            if (currentPage > 0) {
                currentPage--;
                displayPagePair();
            }
        }

        function nextPage() {
            if (currentPage < uniquePages.length - 2) {
                currentPage++;
                displayPagePair();
            }
        }
    </script>
</body>
</html>
